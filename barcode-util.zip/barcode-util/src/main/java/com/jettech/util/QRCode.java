package com.jettech.util;

public class QRCode {
    public static void main(String[] args) throws Exception {
        System.out.println("args0:" + args[0]);
        System.out.println("args1:" + args[1]);
        System.out.println("args2:" + args[2]);
        //编码参数：
        // 必要：-e ，二维码(qr)还是条形码(bar)，字符串内容
        // 可选：输出文件名，输出文件夹路径，输出图片长度和宽度
        //解码参数：
        // 必要：-d ，解码的是二维码还是条形码，图片绝对路径
        // 可选：解码结果输出地，默认输出到终端
        ImgCodeUtil icu = ImgCodeUtil.getInstance();
        if (args.length < 3) {
            System.out.println("请输入必要参数");
            return;
        }
        if (!"e".equals(args[0]) && !"d".equals(args[0])) {
            System.out.println("非法参数");
            return;
        }

        if ("e".equals(args[0])) {
            if (args[2] == null || "".equals(args[2])) {
                System.out.println("请输入要编码的字符串");
                return;
            }
            icu.setContent(args[2]);
            if ("qr".equals(args[1])) {
                icu.encode_QR();
            } else if ("bar".equals(args[1])) {
                icu.encode_128();
            } else {
                icu.encode_DM();
            }
        } else {
            if (args[2] == null || "".equals(args[2]) ) {
                System.out.println("请输入要解码的图片路径");
                return;
            }
            icu.setDeCodeImgPath(args[2]);
            if ("qr".equals(args[1])) {
                System.out.println(icu.decode());
            } else if ("bar".equals(args[1])) {
                //默认输出到终端
                System.out.println(icu.decode());
            } else {
                System.out.println(icu.decode_DM());
            }
        }
    }
}
