package com.jettech.util;

import com.alibaba.fastjson.JSONObject;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.datamatrix.DataMatrixReader;
import com.google.zxing.datamatrix.decoder.Decoder;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.*;

public class ImgCodeUtil {
    private final static ImgCodeUtil INSTANCE = new ImgCodeUtil();
    private ImgCodeUtil() {}
    public  static ImgCodeUtil getInstance() { return INSTANCE; }

    private  String deCodeImgPath;
    private  String outImgPath = System.getProperty("user.dir") + File.separator + "tmp";
    private  String outImgType = "png";
    private  String outImgName = "encodeDemo." + outImgType;
    private  String content = "https://zxing.github.io/zxing/";
    private  int outImgWidth = 144;
    private  int outImgHeight = 144;
    private  BarcodeFormat imgCodeType = BarcodeFormat.QR_CODE;



    public void encode() throws Exception {
        Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 2);
        BitMatrix bitMatrix = new MultiFormatWriter().encode(content,
                imgCodeType, outImgWidth, outImgHeight, hints);
        Path path = FileSystems.getDefault().getPath(outImgPath, outImgName);
        MatrixToImageWriter.writeToPath(bitMatrix, outImgType, path);
    }

    public String decode() throws Exception {
        if (INSTANCE.deCodeImgPath == null) {
            throw new Exception("deCodeImgPath not found!");
        }
        if (!(new File(INSTANCE.deCodeImgPath).exists())) {
            throw new FileNotFoundException();
        }
        BufferedImage image = ImageIO.read(new File(INSTANCE.deCodeImgPath));
        LuminanceSource source = new BufferedImageLuminanceSource(image);
        Binarizer binarizer = new HybridBinarizer(source);
        BinaryBitmap binaryBitmap = new BinaryBitmap(binarizer);
        Map<DecodeHintType, Object> hints = new HashMap<>();
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        Result result = new MultiFormatReader().decode(binaryBitmap, hints);
        return result.getText();
    }

    public String decode_QR() throws Exception {
        String result = INSTANCE.decode();
        JSONObject content = JSONObject.parseObject(result);
        return content.toString();
    }

    public String decode_128() throws Exception {
        return INSTANCE.decode();
    }

    public String decode_DM() throws Exception {
        if (INSTANCE.deCodeImgPath == null) {
            throw new Exception("deCodeImgPath not found!");
        }
        if (!(new File(INSTANCE.deCodeImgPath).exists())) {
            throw new FileNotFoundException();
        }
        Decoder dmDecoder = new Decoder();
        BufferedImage image = ImageIO.read(new File(INSTANCE.deCodeImgPath));
        LuminanceSource source = new BufferedImageLuminanceSource(image);
        Binarizer binarizer = new HybridBinarizer(source);
        BinaryBitmap binaryBitmap = new BinaryBitmap(binarizer);
        DataMatrixReader dmr = new DataMatrixReader();
        Map<DecodeHintType, Object> hints = new HashMap<>();
        hints.put(DecodeHintType.PURE_BARCODE, Boolean.TRUE);
        return dmr.decode(binaryBitmap,hints).getText();
    }

    public void encode_QR() throws Exception {
        INSTANCE.encode();
    }

    public void encode_128() throws Exception {
        INSTANCE.imgCodeType = BarcodeFormat.CODE_128;
        INSTANCE.outImgHeight = 50;
        INSTANCE.encode();
    }

    public void encode_DM() throws Exception {
        INSTANCE.imgCodeType = BarcodeFormat.DATA_MATRIX;
        INSTANCE.encode();
    }

    public  ImgCodeUtil setDeCodeImgPath(String deCodeImgPath) {
        INSTANCE.deCodeImgPath = deCodeImgPath;
        return INSTANCE;
    }

    public  ImgCodeUtil setOutImgPath(String outImgPath) {
        INSTANCE.outImgPath = outImgPath;
        return INSTANCE;
    }

    public  ImgCodeUtil setOutImgType(String outImgType) {
        INSTANCE.outImgType = outImgType;
        return INSTANCE;
    }

    public  ImgCodeUtil setOutImgName(String outImgName) {
        INSTANCE.outImgName = outImgName;
        return INSTANCE;
    }

    public  ImgCodeUtil setContent(String content) {
        INSTANCE.content = content;
        return INSTANCE;
    }

    public  ImgCodeUtil setOutImgWidth(int outImgWidth) {
        INSTANCE.outImgWidth = outImgWidth;
        return INSTANCE;
    }

    public  ImgCodeUtil setOutImgHeight(int outImgHeight) {
        INSTANCE.outImgHeight = outImgHeight;
        return INSTANCE;
    }

    public  ImgCodeUtil setImgCodeType(BarcodeFormat imgCodeType) {
        INSTANCE.imgCodeType = imgCodeType;
        return INSTANCE;
    }


}
