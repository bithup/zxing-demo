package com.jettech.demo;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.datamatrix.DataMatrixReader;
import com.jettech.util.ImgCodeUtil;

public class Demo {
    public static void main(String[] args) throws Exception {
        ImgCodeUtil icu = ImgCodeUtil.getInstance();
//        icu.setContent("this is a demo for qrcode");
//        icu.encode_DM();
        //icu.setContent("6901028075770");//6901028075770
        //icu.encode_128();
        icu.setDeCodeImgPath("C:\\Users\\bithup\\Desktop\\java_proj\\barcode-util\\tmp\\encodeDemo.png");
        String result = icu.decode_DM();
        System.out.println(result);
    }
}
